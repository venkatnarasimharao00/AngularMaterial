# angular-7-role-based-authorization-example

Angular 7 - Role Based Authorization Example with Webpack 4

To see a demo and further details go to http://jasonwatmore.com/post/2018/11/22/angular-7-role-based-authorization-tutorial-with-example